import { View, Text, ScrollView, StyleSheet, Pressable } from 'react-native';
import { format } from 'date-fns';
import { Brain, TrendingUp, Award } from 'lucide-react-native';

export default function HomeScreen() {
  const today = format(new Date(), 'EEEE, MMMM d');

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.date}>{today}</Text>
        <Text style={styles.greeting}>Welcome back, Utkarsh</Text>
      </View>

      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Brain size={24} color="#6366f1" />
          <Text style={styles.statValue}>7 days</Text>
          <Text style={styles.statLabel}>Streak</Text>
        </View>
        <View style={styles.statCard}>
          <TrendingUp size={24} color="#6366f1" />
          <Text style={styles.statValue}>85%</Text>
          <Text style={styles.statLabel}>Progress</Text>
        </View>
        <View style={styles.statCard}>
          <Award size={24} color="#6366f1" />
          <Text style={styles.statValue}>12</Text>
          <Text style={styles.statLabel}>Achievements</Text>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Today's Focus</Text>
        <Pressable style={styles.focusCard}>
          <Text style={styles.focusTitle}>Mindful Breathing</Text>
          <Text style={styles.focusDescription}>
            Take 5 minutes to practice deep breathing and center yourself.
          </Text>
        </Pressable>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Recent Journal Entries</Text>
        <View style={styles.journalPreview}>
          <Text style={styles.journalDate}>Today, 2:30 PM</Text>
          <Text style={styles.journalText} numberOfLines={2}>
            Today was a productive day. I managed to complete all my tasks and had time for self-care...
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  header: {
    padding: 24,
    paddingTop: 60,
    backgroundColor: '#ffffff',
  },
  date: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#64748b',
    marginBottom: 4,
  },
  greeting: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: '#1e293b',
  },
  statsContainer: {
    flexDirection: 'row',
    padding: 16,
    justifyContent: 'space-between',
  },
  statCard: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    alignItems: 'center',
    width: '30%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  statValue: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#1e293b',
    marginTop: 8,
  },
  statLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#64748b',
    marginTop: 4,
  },
  section: {
    padding: 24,
  },
  sectionTitle: {
    fontFamily: 'Inter-SemiBold',
    fontSize: 18,
    color: '#1e293b',
    marginBottom: 16,
  },
  focusCard: {
    backgroundColor: '#6366f1',
    padding: 24,
    borderRadius: 16,
  },
  focusTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: '#ffffff',
    marginBottom: 8,
  },
  focusDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#ffffff',
    opacity: 0.9,
  },
  journalPreview: {
    backgroundColor: '#ffffff',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  journalDate: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#64748b',
    marginBottom: 8,
  },
  journalText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#1e293b',
    lineHeight: 20,
  },
});